'''
Copyright (c)2022 - Soffos.ai - All rights reserved
Created at: 2023-04-28
Purpose: Soffos Services Nodes
-----------------------------------------------------
Nodes are objects that holds the properties of services to initialize the HttpClient
'''

