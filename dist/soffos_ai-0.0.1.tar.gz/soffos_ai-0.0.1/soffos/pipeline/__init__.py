from .basic_pipeline import SoffosPipeline
