'''
Copyright (c)2022 - Soffos.ai - All rights reserved
Created at: 2023-04-01
Purpose: checks the datatype of a dictionary value recursively
-----------------------------------------------------
'''

